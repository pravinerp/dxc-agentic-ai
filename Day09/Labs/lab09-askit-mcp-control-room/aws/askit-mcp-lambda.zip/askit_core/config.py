"""Lambda + S3 version of askit_core/config.py: same names, no .env file. Data is copied from S3 into /tmp (see data.py)."""
from pathlib import Path

DATA_DIR = Path("/tmp/askit_data")
REGION = "us-east-1"
SMALL_MODEL = LARGE_MODEL = ""
